module.exports = {
    apnConfig: {
        token: {
            key: process.env.APN_KEY_PATH, // шлях до вашого .p8 файлу
            keyId: process.env.APN_KEY_ID,
            teamId: process.env.APN_TEAM_ID,
        },
        production: false,
    }
};
